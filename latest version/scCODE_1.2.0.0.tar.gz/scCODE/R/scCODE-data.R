#' A scRNA-seq dataset containg activated CD4+ T cells
#'
#' A scRNA-seq dataset containg activated CD4+ T cells. 13045 genes x 462 cells.
#'
#' @format A conut matrix 13045 genes x 139 cells:
#' \describe{
#'   \item{row}{gene name}
#'   \item{column}{cell name}
#'   ...
#' }
#' @source \url{https://www.science.org/doi/full/10.1126/science.aah4115}
"data1_sccode"

#' A scRNA-seq dataset containg naive CD4+ T cells
#'
#' A scRNA-seq dataset containg naive CD4+ T cells. 13045 genes x 323 cells.
#'
#' @format A conut matrix 13045 genes x 139 cells:
#' \describe{
#'   \item{row}{gene name}
#'   \item{column}{cell name}
#'   ...
#' }
#' @source \url{https://www.science.org/doi/full/10.1126/science.aah4115}
"data2_sccode"
