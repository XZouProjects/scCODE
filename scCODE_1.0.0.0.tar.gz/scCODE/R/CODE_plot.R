#' CODE plot function
#'
#' Plot the results of run_CODE
#' @param CODE_list results of run_CODE
#' @return Heatmap of AUCC
#' @return Heatmap of CDO
#' @return Heatmap of Metrics (AUCC+CDO)
#' @author Jiawei Zou
#' @import pheatmap
#' @export
CODE_plot<-function(list){
  ##AUCC
  AUCC<-list$AUCC
  CDO<-list$CDO
  Metrics<-AUCC+CDO
  pheatmap(AUCC,main = 'AUCC',cluster_rows = F,cluster_cols = F,legend_breaks = c(quantile(AUCC,0.25),quantile(AUCC,0.75)),legend_labels = c('Poor','Good'),fontsize = 13)
  pheatmap(CDO,main = 'CDO',cluster_rows = F,cluster_cols = F,legend_breaks = c(quantile(CDO,0.25),quantile(CDO,0.75)),legend_labels = c('Poor','Good'),fontsize = 13)
  pheatmap(Metrics,main = 'Metrics',cluster_rows = F,cluster_cols = F,legend_breaks = c(quantile(Metrics,0.25),quantile(Metrics,0.75)),legend_labels = c('Poor','Good'),fontsize = 13)

}
